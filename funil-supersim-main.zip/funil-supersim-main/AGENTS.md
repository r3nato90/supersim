<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->
- Gateway PIX do funil, trocável só por env na Vercel. `PIX_GATEWAY_API_KEY` ativa o gateway (padrão `vexigate`); `PIX_GATEWAY` = `vexigate` (nativo: amount em reais, `transaction_id`, `copy_paste`, webhook HMAC) ou `generic` (proxy que traduz o pedido). Opcionais `PIX_GATEWAY_CREATE_URL`, `PIX_GATEWAY_STATUS_URL` (com `{id}`), `PIX_GATEWAY_POSTBACK_URL`, `PIX_GATEWAY_WEBHOOK_SECRET`, `PIX_GATEWAY_MIN_AMOUNT_CENTS` (piso local; padrão 1000 = R$10,00, mínimo confirmado da conta Vexigate). Contrato/adapters em `src/lib/pay-gateway.ts`. Chaves só server-side; never hardcode or expose them.
- The SuperSim funnel ships as static pages under `public/inicio` (cloak routes `/` and `/inicio` redirect there); its payment APIs are the `/api/public/sup-pix`, `sup-status`, `sup-track`, `sup-webhook` server routes; prices and products live only in sup-pix.ts.
- Consulta de CPF da etapa 1 (`public/inicio/2.html`): via proxy server-side `/api/public/sup-cpf?cpf=...` (nunca direto do navegador) — provedor ZipCardX, `GET {CPF_BASE_URL}/consult/{numeros}` com `Authorization: Bearer {CPF_API_KEY}`, validação de dígito local, 404 = não-encontrado, 429 = excesso. Server-side only via `CPF_API_KEY` + `CPF_BASE_URL` (+ opcional `CPF_LIMITE_POR_MINUTO`); resposta `{ success, encontrado, cpf, nome, mae, nascimento, sexo, confere? }`. `sup-pix` exige CPF com dígito válido (igual a `criar-pagamento.php:49` do outro projeto).
