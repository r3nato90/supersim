import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import {
  freepayRequest,
  isFreepaySuccess,
  normalizeFreepayInfo,
  resolveFreepayEnv,
} from "../../../lib/freepay";
import {
  isPrimaryPaid,
  primaryStatus,
  resolvePrimaryEnv,
  verifyWebhookSignature,
} from "../../../lib/pay-gateway";
import { sendMetaCapiEvent } from "../../../lib/meta-capi";

// Webhook de pagamento do gateway configurado no env.
// Vexigate: { transaction_id, external_reference, type, method, status, amount, currency }
//   Assinatura X-Vexigate-Signature (HMAC-SHA256) validada se PIX_GATEWAY_WEBHOOK_SECRET existir.
// Valida pelo shape + consulta a transação na API antes de confiar.
// Fire Purchase na CAPI com event_id = Id da transação (mesmo id do navegador → dedup).
const bodySchema = z
  .object({
    Id: z.string().max(160).optional(),
    id: z.string().max(160).optional(),
    txnId: z.string().max(160).optional(),
    txn_id: z.string().max(160).optional(),
    transaction_id: z.string().max(160).optional(),
    transactionId: z.string().max(160).optional(),
    payment_id: z.string().max(160).optional(),
    type: z.string().max(40).optional(),
    Status: z.string().max(40).optional(),
    status: z.string().max(40).optional(),
    payment_status: z.string().max(40).optional(),
    paymentStatus: z.string().max(40).optional(),
    paid: z.boolean().optional(),
    PaidAt: z.string().max(60).optional(),
    paid_at: z.string().max(60).optional(),
    paidAt: z.string().max(60).optional(),
    Amount: z.number().optional(),
    amount: z.number().optional(),
    amount_cents: z.number().optional(),
    amountCents: z.number().optional(),
    PaymentMethod: z.string().max(30).optional(),
    E2E: z.string().max(160).optional(),
  })
  .passthrough();

export const Route = createFileRoute("/api/public/sup-webhook")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const rawBody = await request.text();
        const env = (globalThis as { process?: { env?: Record<string, string | undefined> } })
          .process?.env;

        // Assinatura HMAC. Se o segredo não estiver configurado, não valida.
        const gatewayEnv = resolvePrimaryEnv(env);
        const hasVexigateSignature = Boolean(
          request.headers.get("x-vexigate-signature") ?? request.headers.get("x-signature"),
        );
        if (hasVexigateSignature && gatewayEnv.webhookSecret) {
          const signature =
            request.headers.get("x-vexigate-signature") ?? request.headers.get("x-signature");
          const valid = await verifyWebhookSignature(rawBody, signature, gatewayEnv.webhookSecret);
          if (!valid) {
            console.error("[sup-webhook] assinatura inválida");
            return Response.json({ ok: false }, { status: 401 });
          }
        }

        let raw: unknown;
        try {
          raw = JSON.parse(rawBody);
        } catch {
          return Response.json({ ok: false }, { status: 400 });
        }
        const parsed = bodySchema.safeParse(raw);
        if (!parsed.success) {
          console.error("[sup-webhook] payload inválido", rawBody.slice(0, 500));
          return Response.json({ ok: false }, { status: 422 });
        }

        const payload = parsed.data;
        // Eventos de saque (payout) não geram Purchase.
        const type = (payload.type ?? "").trim().toLowerCase();
        if (type && type !== "cashin") {
          return Response.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
        }

        const id = (
          payload.Id ??
          payload.id ??
          payload.txnId ??
          payload.txn_id ??
          payload.transaction_id ??
          payload.transactionId ??
          payload.payment_id ??
          ""
        ).trim();
        const status = (
          payload.Status ??
          payload.status ??
          payload.payment_status ??
          payload.paymentStatus ??
          ""
        ).trim();
        if (!id) {
          console.error("[sup-webhook] sem Id", rawBody.slice(0, 300));
          return Response.json({ ok: false }, { status: 422 });
        }
        const paidAtRaw = payload.PaidAt ?? payload.paid_at ?? payload.paidAt ?? "";
        const paid = isPrimaryPaid(
          status,
          typeof paidAtRaw === "string" ? paidAtRaw : "",
          payload.paid,
        );
        console.log("[sup-webhook]", id, status || "?", paid ? "PAID" : "not-paid");

        if (paid) {
          // Valor em reais no webhook; aceita também centavos (amount_cents).
          const rawAmount =
            payload.Amount ?? payload.amount ?? payload.amount_cents ?? payload.amountCents;
          const amountNumber =
            typeof rawAmount === "number" && Number.isFinite(rawAmount) ? rawAmount : undefined;
          const value =
            amountNumber === undefined
              ? undefined
              : payload.amount_cents !== undefined || payload.amountCents !== undefined
                ? amountNumber / 100
                : amountNumber;

          // Confirma na API (fonte da verdade) antes de disparar a Purchase.
          void (async () => {
            try {
              let confirmedAmount: number | undefined;
              let confirmedPaid = false;
              if (gatewayEnv.configured) {
                try {
                  const confirmed = await primaryStatus(id, gatewayEnv);
                  if (confirmed?.paid) {
                    confirmedPaid = true;
                    confirmedAmount = confirmed.amount > 0 ? confirmed.amount / 100 : undefined;
                  }
                } catch (error) {
                  console.error(
                    "[sup-webhook] consulta primária falhou; tentando FreePay",
                    id,
                    error,
                  );
                }
              }
              if (!confirmedPaid) {
                const freepayEnv = resolveFreepayEnv(env);
                if (!freepayEnv.publicKey || !freepayEnv.secretKey) {
                  console.error("[sup-webhook] FreePay sem credenciais para validar", id);
                  return;
                }
                const freepayResult = await freepayRequest(
                  `/v1/payment-transaction/info/${encodeURIComponent(id)}`,
                  {
                    method: "GET",
                    publicKey: freepayEnv.publicKey,
                    secretKey: freepayEnv.secretKey,
                  },
                );
                if (!isFreepaySuccess(freepayResult.httpStatus, freepayResult.data)) {
                  console.error(
                    "[sup-webhook] validação FreePay falhou",
                    id,
                    freepayResult.httpStatus,
                  );
                  return;
                }
                const freepayInfo = normalizeFreepayInfo(freepayResult.data, id);
                if (!freepayInfo.paid) {
                  console.error("[sup-webhook] FreePay API diz não-pago, ignorando", id);
                  return;
                }
                confirmedPaid = true;
                confirmedAmount = freepayInfo.amount > 0 ? freepayInfo.amount : undefined;
              }
              if (!confirmedPaid) return;
              await sendMetaCapiEvent({
                eventName: "Purchase",
                eventId: id,
                value: confirmedAmount ?? value,
                eventSourceUrl: undefined,
              });
            } catch (error) {
              console.error("[sup-webhook] falha no pós-processamento", id, error);
            }
          })();
        }

        return Response.json({ ok: true }, { headers: { "Cache-Control": "no-store" } });
      },
    },
  },
});
