// Consulta de CPF (funil SuperSim) — server-side only.
// Provedor: ZipCardX — GET {CPF_BASE_URL}/consult/{numeros} com
// header `Authorization: Bearer {CPF_API_KEY}`.
// Env vars (nunca hardcodar, nunca expor no navegador):
//   CPF_API_KEY            (token Bearer da conta ZipCardX)
//   CPF_BASE_URL           (ex: https://api.zipcardx.online/api/v1)
//   CPF_LIMITE_POR_MINUTO  (opcional, padrão 12 — rate limit por IP nesta rota)
// Resposta do provedor: 200 flat { CPF, NOME, SEXO, NASC, NOME_MAE }.
// 401 = token inválido, 404 = não-encontrado, 429 = excesso de consultas.

const REQUEST_TIMEOUT_MS = 10_000;

export type CpfEnv = {
  apiKey: string;
  baseUrl: string;
  limitePorMinuto: number;
};

export function resolveCpfEnv(env?: Record<string, string | undefined>): CpfEnv {
  const e =
    env ??
    (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env ??
    {};
  const limiteRaw = Number.parseInt((e["CPF_LIMITE_POR_MINUTO"] ?? "").trim(), 10);
  // Base pública ZipCardX; a chave continua só via CPF_API_KEY.
  const baseDefault = "https://api.zipcardx.online/api/v1";
  return {
    apiKey: (e["CPF_API_KEY"] ?? "").trim(),
    baseUrl: (e["CPF_BASE_URL"] ?? "").trim().replace(/\/+$/, "") || baseDefault,
    limitePorMinuto: Number.isFinite(limiteRaw) && limiteRaw > 0 ? limiteRaw : 12,
  };
}

/** Mesma validação de dígito do Bebidas-Chabas (Documento::cpfValido / checkout.js cpfValido). */
export function cpfValido(valor: unknown): boolean {
  const d = String(valor ?? "").replace(/\D/g, "");
  if (d.length !== 11) return false;
  if (/^(\d)\1{10}$/.test(d)) return false;
  const digito = (ate: number): number => {
    let soma = 0;
    for (let i = 0; i < ate; i++) soma += Number(d.charAt(i)) * (ate + 1 - i);
    const resto = (soma * 10) % 11;
    return resto === 10 ? 0 : resto;
  };
  return digito(9) === Number(d.charAt(9)) && digito(10) === Number(d.charAt(10));
}

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : null;
}

function pickString(data: Record<string, unknown>, ...keys: string[]): string {
  for (const key of keys) {
    const value = data[key];
    if (typeof value === "string" && value.trim()) return value.trim();
  }
  return "";
}

/** Normaliza YYYY-MM-DD → DD/MM/YYYY para exibição no funil. Mantém outros formatos. */
export function normalizarNascimento(valor: string): string {
  const v = valor.trim();
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v);
  if (m) return `${m[3]}/${m[2]}/${m[1]}`;
  return v;
}

/** Mascarado p/ log (nunca logar o CPF cheio). */
export function mascararCpf(numeros: string): string {
  return numeros.length === 11 ? `${numeros.slice(0, 3)}...${numeros.slice(-2)}` : "...";
}

export type CpfConsultaOk = {
  ok: true;
  encontrado: boolean;
  nome: string;
  nomeMae: string;
  nascimento: string;
  sexo: string;
};

export type CpfConsultaFalha = {
  ok: false;
  status: "rate-limit" | "indisponivel";
  mensagem: string;
};

export async function consultarCpf(
  numeros: string,
  env: CpfEnv,
): Promise<CpfConsultaOk | CpfConsultaFalha> {
  let res: Response;
  try {
    res = await fetch(`${env.baseUrl}/consult/${numeros}`, {
      method: "GET",
      headers: { Accept: "application/json", Authorization: `Bearer ${env.apiKey}` },
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
  } catch (error) {
    console.error("[sup-cpf] falha de conexao com zipcardx", mascararCpf(numeros), error);
    return {
      ok: false,
      status: "indisponivel",
      mensagem: "Não foi possível consultar o CPF agora.",
    };
  }

  if (res.status === 404) {
    return { ok: true, encontrado: false, nome: "", nomeMae: "", nascimento: "", sexo: "" };
  }
  if (res.status === 401 || res.status === 403) {
    console.error("[sup-cpf] provedor recusou", res.status, mascararCpf(numeros));
    return {
      ok: false,
      status: "indisponivel",
      mensagem: "Não foi possível consultar o CPF agora.",
    };
  }
  if (res.status === 429) {
    return {
      ok: false,
      status: "rate-limit",
      mensagem: "Muitas consultas seguidas. Tente em instantes.",
    };
  }

  let corpo: unknown = null;
  try {
    corpo = await res.json();
  } catch {
    corpo = null;
  }
  // ZipCardX responde flat { CPF, NOME, SEXO, NASC, NOME_MAE } (sem envelope).
  const interna = asRecord(corpo);
  if (res.status !== 200 || !interna || interna["success"] === false) {
    console.error("[sup-cpf] provedor recusou", res.status, mascararCpf(numeros));
    return {
      ok: false,
      status: "indisponivel",
      mensagem: "Não foi possível consultar o CPF agora.",
    };
  }

  const nome = pickString(interna, "NOME", "nome", "Nome", "name", "NAME");
  const nomeMae = pickString(
    interna,
    "NOME_MAE",
    "NOME_MAE_SOCIAL",
    "MAE",
    "mae",
    "nomeMae",
    "nome_mae",
    "mother",
  );
  const nascimento = normalizarNascimento(
    pickString(interna, "NASC", "nasc", "NASCIMENTO", "nascimento", "data_nasc", "birthDate"),
  );
  const sexo = pickString(interna, "SEXO", "sexo", "gender", "Sexo");

  return {
    ok: true,
    encontrado: nome !== "",
    nome,
    nomeMae,
    nascimento,
    sexo,
  };
}

// Rate limit simples por IP (espelha CPF_LIMITE_POR_MINUTO do outro projeto).
const acessosPorIp = new Map<string, number[]>();

export function excedeuRitmo(ip: string, limitePorMinuto: number): boolean {
  if (!ip || limitePorMinuto <= 0) return false;
  const agora = Date.now();
  const lista = (acessosPorIp.get(ip) ?? []).filter((t) => agora - t < 60_000);
  if (lista.length >= limitePorMinuto) {
    acessosPorIp.set(ip, lista);
    return true;
  }
  lista.push(agora);
  acessosPorIp.set(ip, lista);
  return false;
}
