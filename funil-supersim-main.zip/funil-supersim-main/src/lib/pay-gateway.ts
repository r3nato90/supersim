// Gateway PIX do funil SuperSim — trocável 100% via env na Vercel. Server-side only.
//
// Configuração (env):
//   PIX_GATEWAY_API_KEY = <chave>           (obrigatória p/ ativar o gateway)
//   PIX_GATEWAY = vexigate | generic        (opcional; padrão = vexigate)
//   PIX_GATEWAY_CREATE_URL = <url>          (opcional p/ gateways conhecidos; obrigatória no generic)
//   PIX_GATEWAY_STATUS_URL = <url com {id}> (opcional; default por gateway)
//   PIX_GATEWAY_POSTBACK_URL = <url>        (opcional; webhook por transação)
//   PIX_GATEWAY_WEBHOOK_SECRET = <segredo>  (opcional; habilita verificação HMAC no webhook)
//   PIX_GATEWAY_MIN_AMOUNT_CENTS = <centavos> (opcional; piso local de valor aceito)
//
// Gateways conhecidos (URL default preenchida automaticamente):
//   vexigate → POST https://vexigate.com/api/v1/payments/pix
//              GET  https://vexigate.com/api/v1/payments/{id}
//              amount em REAIS; auth Bearer; mínimo da conta = R$ 10,00 (confirmado via teste).
//   generic  → o cliente informa a URL; enviamos o pedido + aliases
//              (amount_cents/amount_reais, webhook_url/callback_url) e aceitamos
//              várias chaves de resposta (id/txnId/..., qrcode/copy_paste/...).

const REQUEST_TIMEOUT_MS = 20_000;

export type GatewayKind = "vexigate" | "generic";

export type PrimaryEnv = {
  configured: boolean;
  kind: GatewayKind;
  createUrl: string;
  statusUrl: string;
  apiKey: string;
  postbackUrl: string;
  webhookSecret: string;
  minAmountCents: number;
};

const VEXIGATE_CREATE_URL = "https://vexigate.com/api/v1/payments/pix";
const VEXIGATE_STATUS_URL = "https://vexigate.com/api/v1/payments/{id}";
const VEXIGATE_MIN_AMOUNT_CENTS = 1000; // R$ 10,00 (mínimo confirmado na conta via teste real)

function readEnv(env?: Record<string, string | undefined>): Record<string, string | undefined> {
  return (
    env ??
    (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env ??
    {}
  );
}

function parseMinAmountCents(raw: string, fallback: number): number {
  if (!raw) return fallback;
  const parsed = Number.parseInt(raw, 10);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : fallback;
}

export function resolvePrimaryEnv(env?: Record<string, string | undefined>): PrimaryEnv {
  const e = readEnv(env);
  const rawKind = (e["PIX_GATEWAY"] ?? "").trim().toLowerCase();
  const apiKey = (e["PIX_GATEWAY_API_KEY"] ?? "").trim();
  // Padrão: Vexigate. Basta a chave no env; `PIX_GATEWAY=generic` troca p/ proxy genérico.
  const kind: GatewayKind = rawKind === "generic" ? "generic" : "vexigate";
  const createUrl =
    (e["PIX_GATEWAY_CREATE_URL"] ?? "").trim() || (kind === "vexigate" ? VEXIGATE_CREATE_URL : "");
  const statusUrl =
    (e["PIX_GATEWAY_STATUS_URL"] ?? "").trim() || (kind === "vexigate" ? VEXIGATE_STATUS_URL : "");
  const postbackUrl = (e["PIX_GATEWAY_POSTBACK_URL"] ?? "").trim();
  const webhookSecret = (e["PIX_GATEWAY_WEBHOOK_SECRET"] ?? "").trim();
  const isUrl = createUrl.startsWith("http://") || createUrl.startsWith("https://");
  return {
    configured: isUrl && apiKey.length > 0,
    kind,
    createUrl,
    statusUrl,
    apiKey,
    postbackUrl,
    webhookSecret,
    minAmountCents: parseMinAmountCents(
      (e["PIX_GATEWAY_MIN_AMOUNT_CENTS"] ?? "").trim(),
      kind === "vexigate" ? VEXIGATE_MIN_AMOUNT_CENTS : 0,
    ),
  };
}

/** Valor mínimo aceito pelo gateway (evita enviar cobrança que tomaria 422). */
export function primarySupportsAmount(env: PrimaryEnv, amountCents: number): boolean {
  return amountCents >= env.minAmountCents;
}

// ─── helpers ───

function asRecord(value: unknown): Record<string, unknown> | null {
  return value && typeof value === "object" ? (value as Record<string, unknown>) : null;
}

function unwrap(body: Record<string, unknown>): Record<string, unknown> {
  return asRecord(body["data"]) ?? body;
}

function str(value: unknown): string {
  return typeof value === "string" ? value.trim() : "";
}

function firstStr(obj: Record<string, unknown>, keys: string[]): string {
  for (const k of keys) {
    const v = str(obj[k]);
    if (v) return v;
  }
  return "";
}

function authHeaders(apiKey: string): Record<string, string> {
  const headers: Record<string, string> = {
    Accept: "application/json",
    "Content-Type": "application/json",
  };
  if (apiKey) {
    headers["Authorization"] = `Bearer ${apiKey}`;
    headers["X-API-Key"] = apiKey;
  }
  return headers;
}

async function postJson(
  url: string,
  apiKey: string,
  body: unknown,
): Promise<{ httpStatus: number; data: Record<string, unknown> }> {
  const response = await fetch(url, {
    method: "POST",
    headers: authHeaders(apiKey),
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
  });
  let data: Record<string, unknown> = {};
  try {
    const parsed = (await response.json()) as unknown;
    if (parsed && typeof parsed === "object") data = parsed as Record<string, unknown>;
  } catch {
    // corpo não-JSON
  }
  return { httpStatus: response.status, data };
}

async function getJson(
  url: string,
  apiKey: string,
): Promise<{ httpStatus: number; data: Record<string, unknown> } | null> {
  try {
    const response = await fetch(url, {
      method: "GET",
      headers: { Accept: "application/json", ...(apiKey ? authHeaders(apiKey) : {}) },
      signal: AbortSignal.timeout(REQUEST_TIMEOUT_MS),
    });
    let data: Record<string, unknown> = {};
    try {
      const parsed = (await response.json()) as unknown;
      if (parsed && typeof parsed === "object") data = parsed as Record<string, unknown>;
    } catch {
      return null;
    }
    return { httpStatus: response.status, data };
  } catch {
    return null;
  }
}

// ─── payload ───

const UTM_KEYS = [
  "utm_source",
  "utm_medium",
  "utm_campaign",
  "utm_term",
  "utm_content",
  "src",
  "sck",
];

/** Payload genérico: pedido + aliases. O endpoint do cliente traduz. */
function buildGenericPayload(
  fp: Record<string, unknown>,
  env: PrimaryEnv,
): Record<string, unknown> {
  const payload: Record<string, unknown> = { ...fp };
  const amount = fp["amount"];
  if (typeof amount === "number" && Number.isFinite(amount)) {
    payload["amount_cents"] = amount;
    payload["amount_reais"] = amount / 100;
  }
  if (env.postbackUrl) {
    payload["postback_url"] = env.postbackUrl;
    payload["webhook_url"] = env.postbackUrl;
    payload["callback_url"] = env.postbackUrl;
  }
  return payload;
}

/** Payload Vexigate (docs v2.8): amount em reais, customer.document string, UTMs soltas. */
function buildVexigatePayload(
  fp: Record<string, unknown>,
  env: PrimaryEnv,
): Record<string, unknown> {
  const amountCents = typeof fp["amount"] === "number" ? fp["amount"] : 0;
  const customer = asRecord(fp["customer"]) ?? {};
  const doc = asRecord(customer["document"]) ?? {};
  const items = Array.isArray(fp["items"]) ? fp["items"] : [];
  const firstItem = asRecord(items[0]) ?? {};
  const metadata = asRecord(fp["metadata"]) ?? {};

  const body: Record<string, unknown> = {
    amount: Math.round(amountCents) / 100,
    method: "pix",
    customer: {
      name: customer["name"],
      document: doc["number"],
      email: customer["email"],
      phone: customer["phone"],
    },
    external_reference: metadata["order_id"],
  };
  const description = str(firstItem["title"]);
  if (description) body["description"] = description;
  if (env.postbackUrl) body["callback_url"] = env.postbackUrl;

  const tracking: Record<string, string> = {};
  for (const key of UTM_KEYS) {
    const value = str(metadata[key]);
    if (value) {
      body[key] = value;
      tracking[key] = value;
    }
  }
  if (Object.keys(tracking).length) body["tracking_json"] = tracking;
  return body;
}

export function buildPrimaryPayload(
  orderPayload: Record<string, unknown>,
  env: PrimaryEnv,
): Record<string, unknown> {
  return env.kind === "vexigate"
    ? buildVexigatePayload(orderPayload, env)
    : buildGenericPayload(orderPayload, env);
}

export async function primaryCreate(
  payload: Record<string, unknown>,
  env: PrimaryEnv,
): Promise<{ httpStatus: number; data: Record<string, unknown> }> {
  return postJson(env.createUrl, env.apiKey, buildPrimaryPayload(payload, env));
}

// ─── resposta do create ───

export function isPrimarySuccess(httpStatus: number, body: Record<string, unknown>): boolean {
  if (httpStatus < 200 || httpStatus >= 300) return false;
  const txn = unwrap(body);
  return txn["success"] !== false;
}

export function primaryErrorMessage(body: Record<string, unknown>, fallback: string): string {
  const txn = unwrap(body);
  const errors = txn["error_messages"] ?? txn["errors"];
  // Array de objetos/strings: [{ message }] ou ["msg"]
  if (Array.isArray(errors)) {
    for (const item of errors) {
      const message = str(item) || str(asRecord(item)?.["message"]);
      if (message) return message;
    }
  }
  // Objeto por campo: { amount: ["msg"], ... }
  const errorMap = asRecord(errors);
  if (errorMap) {
    for (const value of Object.values(errorMap)) {
      const list = Array.isArray(value) ? value : [value];
      for (const item of list) {
        const message = str(item) || str(asRecord(item)?.["message"]);
        if (message) return message;
      }
    }
  }
  for (const key of ["message", "error", "msg"]) {
    const value = str(txn[key]);
    if (value) return value;
  }
  return fallback;
}

export type PrimaryCreateNormalized = {
  id: string;
  status: string;
  qrCode: string;
  expirationDate: string;
};

const ID_KEYS = [
  "transaction_id",
  "transactionId",
  "txnId",
  "txn_id",
  "payment_id",
  "paymentId",
  "id",
];
const QR_KEYS = [
  "copy_paste",
  "pix_copy_paste",
  "qrcode",
  "qr_code",
  "qrCode",
  "pix_code",
  "pixCode",
  "brcode",
  "br_code",
  "copyPaste",
  "copiaecola",
  "payload",
  "emv",
];

export function normalizePrimaryCreate(
  body: Record<string, unknown>,
): PrimaryCreateNormalized | null {
  const txn = unwrap(body);
  const pix = asRecord(txn["pix"]) ?? {};
  const id = firstStr(txn, ID_KEYS);
  const qrCode =
    firstStr(txn, QR_KEYS) ||
    firstStr(pix, ["qr_code", "qrcode", "qrCode", "code", "copy_paste", "payload"]);
  if (!id || !qrCode) return null;
  const status =
    firstStr(txn, ["status", "payment_status", "paymentStatus", "situacao"]) || "pending";
  const expirationDate =
    firstStr(txn, ["expiration_date", "expirationDate", "expires_at", "expiresAt"]) ||
    firstStr(pix, ["expiration_date", "expires_at"]);
  return { id, status, qrCode, expirationDate };
}

// ─── status ───

const PAID_STATUSES = new Set([
  "PAID",
  "COMPLETED",
  "APPROVED",
  "CONFIRMED",
  "AUTHORIZED",
  "PAGO",
  "PAGA",
  "PAGAMENTO_CONFIRMADO",
  "SUCCESS",
  "SUCCEEDED",
]);

export function isPrimaryPaid(status: string, paidAt: string, paidFlag?: unknown): boolean {
  if (paidFlag === true) return true;
  if (PAID_STATUSES.has(status.toUpperCase())) return true;
  const value = (paidAt || "").trim();
  return value !== "" && !value.startsWith("0001-01-01");
}

export type PrimaryInfoNormalized = {
  id: string;
  status: string;
  paid: boolean;
  paidAt: string;
  amount: number; // centavos
  end2EndId: string;
};

export function normalizePrimaryInfo(
  body: Record<string, unknown>,
  fallbackId: string,
  kind: GatewayKind,
): PrimaryInfoNormalized | null {
  const txn = unwrap(body);
  const pix = asRecord(txn["pix"]) ?? {};
  const id = firstStr(txn, ID_KEYS) || fallbackId;
  const status = firstStr(txn, ["status", "payment_status", "paymentStatus", "situacao"]);
  if (!status && txn["paid"] !== true) return null;
  const paidAt = firstStr(txn, ["paid_at", "paidAt", "PaidAt", "confirmed_at", "confirmedAt"]);
  const amountRaw =
    txn["amount_cents"] ?? txn["amountCents"] ?? txn["Amount"] ?? txn["amount"] ?? txn["value"];
  let amount = typeof amountRaw === "number" && Number.isFinite(amountRaw) ? amountRaw : 0;
  // Gateways que informam em reais (ex: Vexigate) → normaliza p/ centavos.
  if (kind === "vexigate" && amount > 0) amount = Math.round(amount * 100);
  const end2EndId =
    firstStr(txn, ["e2e", "E2E", "End2End", "end_to_end", "endToEnd"]) || firstStr(pix, ["e2e"]);
  return {
    id,
    status: status || "UNKNOWN",
    paid: isPrimaryPaid(status, paidAt, txn["paid"]),
    paidAt: paidAt.startsWith("0001-01-01") ? "" : paidAt,
    amount,
    end2EndId,
  };
}

function statusCandidates(env: PrimaryEnv, id: string): string[] {
  const encoded = encodeURIComponent(id);
  const statusUrl = env.statusUrl;
  if (statusUrl) {
    if (statusUrl.includes("{id}")) return [statusUrl.split("{id}").join(encoded)];
    if (/[?&]id=$/.test(statusUrl)) return [`${statusUrl}${encoded}`];
    if (statusUrl.includes("?")) {
      return [`${statusUrl.replace(/\/*$/, "")}/${encoded}`, `${statusUrl}&id=${encoded}`];
    }
    return [
      `${statusUrl.replace(/\/*$/, "")}/${encoded}`,
      `${statusUrl.replace(/\/*$/, "")}?id=${encoded}`,
    ];
  }
  const base = env.createUrl.replace(/\/*$/, "");
  return [`${base}/${encoded}`, `${base}?id=${encoded}`];
}

/** Consulta o status no primário (tenta variações de URL). Null = sem resposta útil. */
export async function primaryStatus(
  id: string,
  env: PrimaryEnv,
): Promise<PrimaryInfoNormalized | null> {
  for (const url of statusCandidates(env, id)) {
    const result = await getJson(url, env.apiKey);
    if (!result || result.httpStatus === 404) continue;
    if (!isPrimarySuccess(result.httpStatus, result.data)) continue;
    const info = normalizePrimaryInfo(result.data, id, env.kind);
    if (info) return info;
  }
  return null;
}

// ─── webhook ───

/** Verifica X-Vexigate-Signature: `sha256=<hmac-sha256(rawBody, secret)>`. */
export async function verifyWebhookSignature(
  rawBody: string,
  signatureHeader: string | null,
  secret: string,
): Promise<boolean> {
  if (!secret) return true; // sem segredo configurado, não valida
  if (!signatureHeader) return false;
  const provided = signatureHeader.trim().replace(/^sha256=/i, "");
  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"],
  );
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(rawBody));
  const hex = [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, "0")).join("");
  if (hex.length !== provided.length) return false;
  let diff = 0;
  for (let i = 0; i < hex.length; i++) diff |= hex.charCodeAt(i) ^ provided.charCodeAt(i);
  return diff === 0;
}
